#ifndef VNSTAT_H
#define VNSTAT_H

int synccounters(const char *iface, const char *dirname);

#endif
