#ifndef VNSTATD_H
#define VNSTATD_H

void daemonize(void);
int addinterfaces(const char *dirname);

#endif
