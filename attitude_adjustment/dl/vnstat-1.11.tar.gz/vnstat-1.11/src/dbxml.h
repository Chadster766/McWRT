#ifndef DBXML_H
#define DBXML_H

void showxml(void);
void xmldate(time_t *date, int type);

#endif
