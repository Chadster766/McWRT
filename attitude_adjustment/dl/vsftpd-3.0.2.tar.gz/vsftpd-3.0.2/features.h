#ifndef VSF_FEATURES_H
#define VSF_FEATURES_H

struct vsf_session;

void handle_feat(struct vsf_session* p_sess);

#endif /* VSF_FEATURES_H */

