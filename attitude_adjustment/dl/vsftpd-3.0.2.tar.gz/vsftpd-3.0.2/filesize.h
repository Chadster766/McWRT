#ifndef VSF_FILESIZE_H
#define VSF_FILESIZE_H

typedef long long filesize_t;

#endif /* VSF_FILESIZE_H */

